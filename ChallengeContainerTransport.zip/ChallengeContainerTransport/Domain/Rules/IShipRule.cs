﻿using ContainerChallenge.Domain;

namespace ChallengeContainerTransport.Domain.Rules
{
    public interface IShipRule
    {
        bool IsValid(ShipGrid ship, out string error);
    }
}

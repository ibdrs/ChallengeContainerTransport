﻿using ContainerChallenge.Domain;

namespace ChallengeContainerTransport.Domain.Rules
{
    public interface IPlacementRule
    {
        bool CanPlace(ShipGrid ship, Position pos, Container container, out string error);
    }
}

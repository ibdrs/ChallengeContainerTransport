﻿namespace ContainerChallenge.Domain;
public enum ContainerType
{
    Normal = 1,
    Valuable = 2,
    Coolable = 3,
    ValuableCoolable = 4
}

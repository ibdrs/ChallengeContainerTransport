﻿namespace ContainerChallenge.Domain;
public readonly record struct Position(int Row, int Col);
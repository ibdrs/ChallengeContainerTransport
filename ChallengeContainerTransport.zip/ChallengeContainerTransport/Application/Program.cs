﻿using ChallengeContainerTransport.Domain.Rules;
using ContainerChallenge.Algorithm;
using ContainerChallenge.Export;

Console.WriteLine("Container Challenge (Console)");

var request = new PlacementRequest
{
    Length = 3,
    Width = 3,

    NormalCount = 10,
    ValuableCount = 2,
    CoolableCount = 2,
    ValuableCoolableCount = 1,

    NormalWeightTons = 30,
    ValuableWeightTons = 30,
    CoolableWeightTons = 30,
    ValuableCoolableWeightTons = 30
};

var placementRules = new IPlacementRule[]
{
    new CoolableMustBeFrontRowRule(),
    new ValuableMustBeEdgeRowRule(),
    new NoContainerAboveValuableRule(),
    new MaxWeightAboveRule(),
};

var shipRules = new IShipRule[]
{

};

var placementValidator = new PlacementValidator(placementRules);
var shipValidator = new ShipValidator(shipRules);

var algorithm = new MyAlgorithm(placementValidator, shipValidator);

// RUN
var response = algorithm.Run(request);
var ship = response.Ship;

// console output + debug
Console.WriteLine($"Unplaced containers: {response.UnplacedCount}");

foreach (var u in response.Unplaced)
{
    Console.WriteLine($"- Id {u.Id} ({u.Type}, {u.WeightTons}t)");
    foreach (var reason in u.Reasons)
        Console.WriteLine($"  * {reason}");
}

if (response.Errors.Count > 0)
{
    Console.WriteLine("Ship validation errors:");
    foreach (var error in response.Errors)
        Console.WriteLine($"- {error}");
}

var exporter = new VisualizerExporter();
var url = exporter.ToUrl(ship);

Console.WriteLine("Visualizer URL:");
Console.WriteLine(url);
